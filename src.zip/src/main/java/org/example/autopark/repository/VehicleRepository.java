package org.example.autopark.repository;

import org.example.autopark.entity.Vehicle;
import org.springframework.context.annotation.Profile;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
@Profile("!reactive")
public interface VehicleRepository extends JpaRepository<Vehicle, Long>, JpaSpecificationExecutor<Vehicle> {
    Optional<Vehicle> findByGuid(UUID guid);

    List<Vehicle> findVehiclesByEnterpriseOwnerOfVehicle_EnterpriseId(Long id);

    boolean existsByLicensePlate(String licensePlate);
    boolean existsByLicensePlateAndVehicleIdNot(String licensePlate, Long vehicleId);
    Optional<Vehicle> findByLicensePlate(String licensePlate);
    List<Vehicle> findByLicensePlateContainingIgnoreCase(String licensePlatePart);

}
