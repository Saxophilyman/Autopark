package org.example.autopark.exception;

public class EnterpriseNotUpdatedException extends RuntimeException{
    public EnterpriseNotUpdatedException(String msg) {
        super(msg);
    }
}
