package org.example.autopark.exception;

public class EnterpriseNotDeletedException extends RuntimeException{
    public EnterpriseNotDeletedException(String msg) {
        super(msg);
    }
}
