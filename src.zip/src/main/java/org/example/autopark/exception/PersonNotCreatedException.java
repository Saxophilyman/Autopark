package org.example.autopark.exception;

public class PersonNotCreatedException extends  RuntimeException{
    public PersonNotCreatedException(String msg){
        super(msg);
    }
}
