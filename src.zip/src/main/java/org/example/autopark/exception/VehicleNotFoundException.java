package org.example.autopark.exception;

public class VehicleNotFoundException extends RuntimeException{
   // public VehicleNotFoundException(String message){super(message);}
}
