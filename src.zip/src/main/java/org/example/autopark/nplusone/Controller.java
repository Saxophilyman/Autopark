package org.example.autopark.nplusone;

public class Controller {
}
