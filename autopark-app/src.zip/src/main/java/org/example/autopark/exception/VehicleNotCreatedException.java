package org.example.autopark.exception;

public class VehicleNotCreatedException extends RuntimeException {

    public VehicleNotCreatedException(String msg) {
        super(msg);
    }

}
