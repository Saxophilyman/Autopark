package org.example.autopark.exception;

public class NotCreatedException extends RuntimeException {
    public NotCreatedException(String msg) {
        super(msg);
    }
}
