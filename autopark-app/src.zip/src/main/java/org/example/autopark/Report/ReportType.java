package org.example.autopark.Report;

public enum ReportType {
    VEHICLE_MILEAGE // Пробег автомобиля
}
