package org.example.autopark.trip;

public record VehicleTripsRowDto(Long vehicleId, String licensePlate, long tripsCount) {}
