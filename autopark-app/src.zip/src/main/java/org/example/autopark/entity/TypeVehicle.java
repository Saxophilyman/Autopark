package org.example.autopark.entity;

public enum TypeVehicle {
        MOTORCYCLE, CAR, TRUCK, BUSE, MOPED

}
