package org.example.autopark.controllers.managers.APIControllers;

import jakarta.validation.Valid;
import org.example.autopark.appUtil.ValidationBindingUtil;
import org.example.autopark.dto.DriverDTO;
import org.example.autopark.dto.VehicleDTO;
import org.example.autopark.dto.mapper.VehicleMapper;
import org.example.autopark.entity.Driver;
import org.example.autopark.entity.Enterprise;
import org.example.autopark.entity.Vehicle;
import org.example.autopark.exception.VehicleErrorResponse;
import org.example.autopark.exception.VehicleNotCreatedException;
import org.example.autopark.exception.VehicleNotFoundException;
import org.example.autopark.security.ManagerDetails;
import org.example.autopark.service.DriverService;
import org.example.autopark.service.EnterpriseService;
import org.example.autopark.service.VehicleService;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@Profile("!reactive")
@RequestMapping("/api/managers")
public class ApiManagerController {
    private final EnterpriseService enterprisesService;
    private final VehicleService vehicleService;
    private final DriverService driversService;
    private final VehicleMapper vehicleMapper;
    private final ModelMapper modelMapper;

    Logger logger = LoggerFactory.getLogger(ApiManagerController.class);

    public ApiManagerController(EnterpriseService enterprisesService, VehicleService vehicleService,
                                DriverService driversService, VehicleMapper vehicleMapper, ModelMapper modelMapper) {
        this.enterprisesService = enterprisesService;
        this.vehicleService = vehicleService;
        this.driversService = driversService;
        this.vehicleMapper = vehicleMapper;
        this.modelMapper = modelMapper;
    }

    @GetMapping
    public ModelAndView start(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        ManagerDetails managerDetails = (ManagerDetails) authentication.getPrincipal();
        model.addAttribute("manager", managerDetails.getManager());

        return new ModelAndView("startPage");
    }

    // ----------------- CRUD CRUD FOR ENTERPRISES -----------------
    //GET
//    @GetMapping("/{id}/enterprises")
//    public List<Enterprise> indexEnterprises(@PathVariable("id") Long id) {
//        return enterprisesService.findEnterprisesForManager(id);
//    }

    //PUT
    @PutMapping("/{id}/enterprises/{idEnterprise}")
    public ResponseEntity<HttpStatus> update(@PathVariable("id") Long idManager,
                                             @RequestBody @Valid Enterprise enterprise,
                                             BindingResult bindingResult,
                                             @PathVariable("idEnterprise") Long idEnterprise) {
        ValidationBindingUtil.Binding(bindingResult);
        enterprisesService.update(idManager, idEnterprise, enterprise);
        return ResponseEntity.ok(HttpStatus.OK);
    }

    //POST
    @PostMapping("/{id}/enterprises")
    public ResponseEntity<Void> create(@RequestBody @Valid Enterprise enterprise,
                                       BindingResult bindingResult,
                                       @PathVariable("id") Long id) {
        ValidationBindingUtil.Binding(bindingResult);
        enterprisesService.save(enterprise, id);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    //DELETE
    @DeleteMapping("/{id}/enterprises/{idEnterprise}")
    public ResponseEntity<Void> delete(@PathVariable("id") Long idManager,
                                       @PathVariable("idEnterprise") Long idEnterprise) {
        enterprisesService.delete(idManager, idEnterprise);
        return ResponseEntity.noContent().build(); // Возвращаем 204 No Content
    }

    //UPDATE
//----------------------//


        //PUT
    @PutMapping("/{id}/vehicles/{idVehicle}")
    public ResponseEntity<HttpStatus> update(@RequestBody @Valid VehicleDTO vehicle,
                                             BindingResult bindingResult,
                                             @PathVariable("idVehicle") Long idVehicle) {
        ValidationBindingUtil.Binding(bindingResult);
        vehicleService.update(idVehicle, convertToVehicle(vehicle));
        return ResponseEntity.ok(HttpStatus.OK);
    }

    //POST
    @PostMapping("/{id}/vehicles")
    public ResponseEntity<Void> create(@RequestBody @Valid VehicleDTO vehicle,
                                       BindingResult bindingResult) {
        logger.info("Received vehicle: {}", vehicle);
        ValidationBindingUtil.Binding(bindingResult);
        vehicleService.save(convertToVehicle(vehicle));
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    //DELETE
    @DeleteMapping("/{id}/vehicles/{idVehicle}")
    public ResponseEntity<Void> deleteVehicle(@PathVariable("idVehicle") Long id) {
        vehicleService.delete(id);

        return ResponseEntity.noContent().build(); // Возвращаем 204 No Content
    }

    //UPDATE
//----------------------//

    //CRUD FOR DRIVERS
    //GET
    @GetMapping("/{id}/drivers")
    public List<DriverDTO> indexDrivers(@PathVariable("id") Long id) {
        return driversService.findDriversForManager(id).stream().map(this::convertToDriverDTO)
                .collect(Collectors.toList());
    }

    //PUT
    @PutMapping("/{id}/drivers/{idDriver}")
    public ResponseEntity<HttpStatus> update(@RequestBody @Valid DriverDTO driverDTO,
                                             BindingResult bindingResult,
                                             @PathVariable("idDriver") Long id) {
        ValidationBindingUtil.Binding(bindingResult);

        driversService.update(id, convertToDriver(driverDTO));

        return ResponseEntity.ok(HttpStatus.OK);
    }

    //
    //POST
    @PostMapping("/{id}/drivers")
    public ResponseEntity<Void> create(@RequestBody @Valid DriverDTO driverDTO,
                                       BindingResult bindingResult) {
        logger.info("Received vehicle: {}", driverDTO);
        ValidationBindingUtil.Binding(bindingResult);
        driversService.save(convertToDriver(driverDTO));
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    //DELETE
    @DeleteMapping("/{id}/drivers/{idDriver}")
    public ResponseEntity<Void> deleteDriver(@PathVariable("idDriver") Long id) {
        driversService.delete(id);
        return ResponseEntity.noContent().build(); // Возвращаем 204 No Content
    }

    //UPDATE
//----------------------//


    //внутренние методы


    private Vehicle convertToVehicle(VehicleDTO vehicleDTO) {
        return modelMapper.map(vehicleDTO, Vehicle.class);
    }

    private VehicleDTO convertToVehicleDTO(Vehicle vehicle) {
        return modelMapper.map(vehicle, VehicleDTO.class);
    }

    private DriverDTO convertToDriverDTO(Driver driver) {
        return modelMapper.map(driver, DriverDTO.class);
    }

    private Driver convertToDriver(DriverDTO driverDTO) {
        return modelMapper.map(driverDTO, Driver.class);
    }


    @ExceptionHandler
    private ResponseEntity<VehicleErrorResponse> handlerException(VehicleNotFoundException e) {
        VehicleErrorResponse response = new VehicleErrorResponse(
                "Vehicle with this id wasn't found",
                System.currentTimeMillis()
        );

        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND); // статус 404
    }

    @ExceptionHandler
    private ResponseEntity<VehicleErrorResponse> handlerException(VehicleNotCreatedException e) {
        VehicleErrorResponse response = new VehicleErrorResponse(
                e.getMessage(),
                System.currentTimeMillis()
        );

        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST); // статус 400
    }
}
