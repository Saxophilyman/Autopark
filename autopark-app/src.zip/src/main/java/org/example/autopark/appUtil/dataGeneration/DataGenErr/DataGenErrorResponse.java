package org.example.autopark.appUtil.dataGeneration.DataGenErr;

public class DataGenErrorResponse {
}
