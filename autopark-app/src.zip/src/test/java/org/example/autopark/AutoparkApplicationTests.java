package org.example.autopark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoparkApplicationTests {

	@Test
	void contextLoads() {
	}

}
